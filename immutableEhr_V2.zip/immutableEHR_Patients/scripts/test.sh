#!/bin/bash
var="kjh"

if [[ -n "$var" ]]; then
    echo "not empty"
else
    echo "empty"
fi